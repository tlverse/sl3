## ----install_pkg---------------------------------------------------------
if (!("sl3" %in% installed.packages())) {
  devtools::install_github("jeremyrcoyle/sl3")
}

## ----prelims-------------------------------------------------------------
set.seed(49753)
library(data.table)
library(dplyr)

# packages we'll be using
library(sl3)
library(origami)
library(SuperLearner)

# load example data set
data(cpp)
cpp <- cpp %>%
  dplyr::filter(!is.na(haz)) %>%
  mutate_all(funs(replace(., is.na(.), 0)))

# here are the covariates we are interested in, and the outcome of course
covars <- c("apgar1", "apgar5", "parity", "gagebrth", "mage", "meducyrs",
            "sexn")
outcome <- "haz"

## ----sl3-task-create-----------------------------------------------------
task <- sl3_Task$new(cpp, covariates = covars, outcome = outcome)

## ----sl3-task-examine----------------------------------------------------
task

## ----sl3-task-nodes------------------------------------------------------
task$nodes

## ----sl3-learners-screeners----------------------------------------------
slscreener <- Lrnr_pkg_SuperLearner_screener$new("screen.glmnet")
glm_learner <- Lrnr_glm$new()

## ----sl3-pipelines-------------------------------------------------------
screen_and_glm <- Pipeline$new(slscreener, glm_learner)
SL.glmnet_learner <- Lrnr_pkg_SuperLearner$new(SL_wrapper = "SL.glmnet")
sg_fit <- screen_and_glm$train(task)
print(sg_fit)

## ----sl3-stack-----------------------------------------------------------
learner_stack <- Stack$new(SL.glmnet_learner, glm_learner, screen_and_glm)
stack_fit <- learner_stack$train(task)

## ----sl3-stack-preds-----------------------------------------------------
preds <- stack_fit$predict()
head(preds)

## ----sl3-cv-stack--------------------------------------------------------
cv_stack <- Lrnr_cv$new(learner_stack)
cv_fit <- cv_stack$train(task)

## ----sl3-metalearner-glm-------------------------------------------------
glm_stack <- Pipeline$new(cv_stack, glm_learner)
ml_fit <- glm_stack$train(task)

## ----sl3-mlfit-mod-------------------------------------------------------
print(ml_fit)

## ----sl3-mlfit-preds-----------------------------------------------------
ml_fit_preds <- ml_fit$predict()
head(ml_fit_preds)

## ----sl3-learner-SL------------------------------------------------------
# convenience learner combining all this
sl <- Lrnr_sl$new(learners = list(SL.glmnet_learner, glm_learner,
                                  screen_and_glm),
                  metalearner = glm_learner)
sl_fit <- sl$train(task)

## ----sessionInfo, echo=FALSE---------------------------------------------
sessionInfo()

