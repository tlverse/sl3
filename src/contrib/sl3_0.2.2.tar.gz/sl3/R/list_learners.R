# 
# learners <- list(Lrnr_cv, Lrnr_glm, Lrnr_glm_fast, Lrnr_model.matrix, Lrnr_pkg_SuperLearner, 
#     Lrnr_pkg_SuperLearner_screener, Lrnr_sl, Lrnr_h2o_glm)
