library(testthat)
library(sl3)

test_check("sl3")
